export const bucketName = process.env.AWS_S3_BUCKET_NAME;
