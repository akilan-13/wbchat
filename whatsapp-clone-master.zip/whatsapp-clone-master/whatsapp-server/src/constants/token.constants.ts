export const refreshTokenExp = 7 * 24 * 60 * 60 * 1000;
export const accessTokenExp = 30 * 1000;
