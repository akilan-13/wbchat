export const potraitOffset = {
    xOffset: 100,
    yOffset: 130,
};

export const landscapeOffset = {
    xOffset: 160,
    yOffset: 100,
};
