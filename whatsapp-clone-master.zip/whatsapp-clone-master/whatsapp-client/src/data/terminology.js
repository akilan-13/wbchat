const chatTypes = {
    textMsg: {
        component: "",
    },
};
