import s from "./header.module.scss";

export const RoomHeader = () => {
    return <div className={s.roomHeader}></div>;
};
