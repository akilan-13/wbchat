import VideocamIcon from "@material-ui/icons/Videocam";

export const Video = () => {
    return (
        <small>
            <div className="a-f-a">
                <VideocamIcon />
                Video
            </div>
        </small>
    );
};
