import PhotoCameraIcon from "@material-ui/icons/PhotoCamera";

export const Picture = () => {
    return (
        <small>
            <div className="a-f-a">
                <PhotoCameraIcon />
                Photo
            </div>
        </small>
    );
};
