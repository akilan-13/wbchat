import MusicNoteIcon from "@material-ui/icons/MusicNote";

export const Voice = () => {
    return (
        <small>
            <div className="a-f-a">
                <MusicNoteIcon />
                Audio
            </div>
        </small>
    );
};
