import s from "../sidebarModal.module.scss";

export const ArchivedSidebar = () => {
    return <div className={s.sidebarModalBody}></div>;
};
